# AI Software Architect — Frontend

React + Vite frontend for the `AI Software Architect API` (`app.py`, FastAPI + LangGraph).

## What this does, and what it deliberately does not do

The backend currently exposes exactly two routes:

- `GET /` — health check
- `POST /generate` — synchronous call that runs the full multi-agent workflow and returns the complete architecture in one response

There is **no** streaming/progress endpoint and **no** PDF/export endpoint on the backend today. So this frontend:

- Shows a single honest loading state during `/generate` (no fake per-stage progress bar)
- Has **no download-PDF button** calling the API — that endpoint doesn't exist
- Does offer a client-side **"Print / Save as PDF"** on each sheet, which uses the browser's native print dialog. That's real functionality that doesn't depend on the backend at all — not a stand-in for a real export endpoint.

If you add streaming or export endpoints to the backend later, the natural extension points are `src/services/api.js` (add the new calls) and `src/hooks/useGenerateArchitecture.js` (swap the single `await` for an `EventSource`/polling loop).

## Project structure

```
src/
├── components/     # Reusable UI: Navbar, Sidebar, forms, states, sheet renderers
├── pages/          # HomePage (intake) and ResultsPage (sheet index + content)
├── services/       # api.js — the ONLY place that talks to the backend
├── hooks/          # useGenerateArchitecture — request lifecycle + session cache
├── utils/          # sheets.js — single source of truth mapping API fields to UI sheets
├── styles/         # tokens.css — design system variables
├── App.jsx
└── main.jsx
```

## Install

Requires Node.js 18+.

```bash
npm install
```

## Configure the backend URL

```bash
cp .env.example .env
```

Edit `.env`:

```
VITE_API_URL=http://127.0.0.1:8000
```

This must point at wherever your FastAPI app (`uvicorn app:run`, given the `app.py` you provided uses `run = FastAPI(...)`) is actually running. No API keys belong in this file or anywhere in the frontend — the LLM keys stay entirely server-side in the LangGraph backend.

## Run

Start your backend first (adjust to your actual entry point):

```bash
uvicorn app:run --reload --port 8000
```

Then, in this project:

```bash
npm run dev
```

Open the printed local URL (default `http://localhost:5173`).

## Build for production

```bash
npm run build
npm run preview   # sanity-check the production build locally
```

Deploy the `dist/` folder to any static host. Set `VITE_API_URL` at build time to your production backend URL — Vite inlines `import.meta.env.VITE_*` values at build time, so it must be set before `npm run build`, not just at runtime.

## API integration notes

- Request body sent to `POST /generate`:
  ```json
  { "project_name": "string, >=4 chars", "user_prompt": "string, >=15 chars" }
  ```
  The frontend enforces these same minimums client-side before submitting, mirroring the Pydantic `Field` constraints in `InputProject`.

- Response fields consumed: `success`, `project_name`, and `architecture.{requirements, database, backend, frontend, api, ai_design, deployment, timeline, cost, review_score, messages}` — exactly the `LangGraph` state fields in `app.py`. Nothing is assumed beyond that shape.

- Errors: the backend returns different shapes depending on whether FastAPI's own request validation fails (422, `detail` is an array) or your custom `except` blocks fire (`detail` is `{error, message, details?}`, statuses 422/500/503/504). `services/api.js` normalizes both into one shape (`{status, title, message, details}`) so every UI error state renders consistently regardless of origin.

- If `/generate` is slow for realistic prompts, the client-side axios timeout is currently set to 180s in `services/api.js` (`client.timeout`). Raise this if your LangGraph pipeline routinely takes longer, or (better) move to an async job + polling/SSE pattern on the backend so the user isn't stuck on one indefinite request.
