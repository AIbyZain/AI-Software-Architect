# AI Software Architect — Frontend

React + Vite frontend for the AI Software Architect FastAPI backend
(`api.py`). Built directly against the three endpoints the backend
exposes:

- `POST /generate` — submit a project name + description, receive the
  generated architecture.
- `GET /reports` — list generated report files.
- `GET /reports/download` — download all reports as a ZIP.

## Setup

```bash
npm install
cp .env.example .env
# edit .env and set VITE_API_URL to your backend, e.g.
# VITE_API_URL=http://localhost:8000
npm run dev
```

The app runs at `http://localhost:5173`, which matches the origin the
backend's CORS config already allows.

## Build

```bash
npm run build
npm run preview
```

## Deploying (Netlify)

Set `VITE_API_URL` as an environment variable in your Netlify site
settings to point at the deployed FastAPI backend. The backend's CORS
config already allows `https://aisoftwarearchitect.netlify.app`.

## Project structure

```
src/
  api/            Centralized API client + endpoint calls
  components/     UI components (form, results, reports, etc.)
  hooks/          Generation + reports state management
  utils/          Content parsing for rendering architecture text
  App.jsx         Page composition
  index.css       Global styles / design tokens
```

## Notes

- Validation mirrors the backend's Pydantic constraints exactly:
  project name ≥ 4 characters, description ≥ 15 characters.
- Error messages map the backend's 422 / 500 / 503 / 504 responses to
  plain, human-readable text — no stack traces are surfaced.
- No mock data or hardcoded architecture results — every screen reflects
  the live API response.
